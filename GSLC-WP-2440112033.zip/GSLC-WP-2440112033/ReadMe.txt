1. Download project
2. Open XAMPP
3. Start Apache and MySQL
4. Make new database name = "wp"
5. Open project in VSCODE
6. Open file .env 
7. change DB_PORT to your port 
8. Add Google client id and google client secret
You can get that from this link "https://console.cloud.google.com/apis"
9. Open terminal
10. Use command "php artisan migrate:fresh --seed"
11. Use command "php artisan serve"
12. Ctrl + click server to open the website